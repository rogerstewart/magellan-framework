﻿using System.Windows;
using Magellan;

namespace $safeprojectname$
{
    public partial class MainWindow : Window
    {
        public MainWindow(INavigatorFactory navigation)
        {
            InitializeComponent();

            // We use the INavigatorFactory to create an INavigator linked to the <Frame /> in this Window
            // If we had multiple frames, we could use it to create multiple navigators.
            MainNavigator = navigation.CreateNavigator(MainFrame);
        }

        public INavigator MainNavigator { get; set; }
    }
}
