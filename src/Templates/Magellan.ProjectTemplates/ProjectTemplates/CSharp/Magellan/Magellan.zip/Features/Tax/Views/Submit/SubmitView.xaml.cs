﻿using System.Windows.Controls;

namespace $safeprojectname$.Features.Tax.Views.Submit
{
    public partial class SubmitView : Page
    {
        public SubmitView()
        {
            InitializeComponent();
        }
    }
}
