﻿using System.Windows;

namespace $safeprojectname$.Features.Home.Views.About
{
    public partial class AboutView : Window
    {
        public AboutView()
        {
            InitializeComponent();
        }
    }
}
