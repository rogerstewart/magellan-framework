﻿using System.Windows.Controls;

namespace $safeprojectname$.Features.Home.Views.Index
{
    public partial class IndexView : Page
    {
        public IndexView()
        {
            InitializeComponent();
        }
    }
}
