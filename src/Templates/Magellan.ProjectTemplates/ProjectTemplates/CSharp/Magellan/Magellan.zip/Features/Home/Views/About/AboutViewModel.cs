﻿using Magellan.Framework;

namespace $safeprojectname$.Features.Home.Views.About
{
    public class AboutViewModel : ViewModel
    {
    }
}
