﻿using Magellan.Framework;
using $safeprojectname$.Features.Home.Views.About;
using $safeprojectname$.Features.Home.Views.Index;

namespace $safeprojectname$.Features.Home
{
    public class HomeController : Controller
    {
        //
        // Example URL: /Home/Index
        public ActionResult Index()
        {
            return Page("Index", new IndexViewModel());
        }

        //
        // Example URL: /Home/About
        public ActionResult About()
        {
            return Dialog("About", new AboutViewModel());
        }
    }
}
