﻿using System.Windows.Controls;

namespace $safeprojectname$.Features.Tax.Views.EnterDetails
{
    public partial class EnterDetailsView : Page
    {
        public EnterDetailsView()
        {
            InitializeComponent();
        }
    }
}
