﻿namespace $safeprojectname$.Features.Tax.Model
{
    public interface ITaxEstimator
    {
        TaxEstimate Estimate(Situation situation);
    }
}