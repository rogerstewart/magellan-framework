﻿namespace $safeprojectname$.Features.Tax.Model
{
    public static class TaxSelectorFactory
    {
        public static ITaxEstimatorSelector CreateSelector()
        {
            // Tax settings
            var taxes = new TaxEstimatorSelector();
            taxes.AddTaxRate(
                TaxPeriod.FY2009,
                new TaxEstimator(
                    new TaxBracketSelector(
                        new TaxBracket(-1, 6000M, 0, 0),
                        new TaxBracket(6000M, 35000M, 0, 0.15M),
                        new TaxBracket(35000M, 80000M, 4350, 0.30M),
                        new TaxBracket(80000M, 180000M, 17850, 0.38M),
                        new TaxBracket(180000M, decimal.MaxValue, 55850, 0.45M)
                        ),
                    new MedicareLevy(70000, 0.015M))
                );
            taxes.AddTaxRate(
                TaxPeriod.FY2010,
                new TaxEstimator(
                    new TaxBracketSelector(
                        new TaxBracket(-1, 6000M, 0, 0),
                        new TaxBracket(6000M, 37000M, 0, 0.15M),
                        new TaxBracket(37000M, 80000M, 4650, 0.30M),
                        new TaxBracket(80000M, 180000M, 17550, 0.37M),
                        new TaxBracket(180000M, decimal.MaxValue, 54550, 0.45M)
                        ),
                    new MedicareLevy(70000, 0.015M))
                );
            return taxes;
        }
    }
}
