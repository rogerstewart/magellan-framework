﻿using Magellan.Framework;
using $safeprojectname$.Features.Tax.Model;
using $safeprojectname$.Features.Tax.Views.EnterDetails;
using $safeprojectname$.Features.Tax.Views.Submit;

namespace $safeprojectname$.Features.Tax
{
    public class TaxController : Controller
    {
        private readonly ITaxEstimatorSelector _estimatorSelector;

        public TaxController(ITaxEstimatorSelector estimatorSelector)
        {
        	// Inject the TaxEstimateSelector so it can be used by the Submit() action
            _estimatorSelector = estimatorSelector;
        }

        // Example URL: /Tax/EnterDetails
        public ActionResult EnterDetails()
        {
            return Page("EnterDetails", new EnterDetailsViewModel());
        }

        // Example URL: /Tax/Submit?period=FY2010&grossIncome=50000
        public ActionResult Submit(TaxPeriod period, decimal grossIncome)
        {
            var situation = new Situation(grossIncome);
            var estimator = _estimatorSelector.Select(period);
            var estimate = estimator.Estimate(situation);

            return Page("Submit", new SubmitViewModel(estimate));
        }
    }
}

