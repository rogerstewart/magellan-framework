﻿using System.Windows;
using Magellan;
using Magellan.Framework;
using $safeprojectname$.Features.Home;
using $safeprojectname$.Features.Tax;
using $safeprojectname$.Features.Tax.Model;

namespace $safeprojectname$
{
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Configure Magellan - first by setting up controllers
            var controllerFactory = new AsyncControllerFactory();
            controllerFactory.Register("Home", () => new HomeController());
            controllerFactory.Register("Tax", () => new TaxController(TaxSelectorFactory.CreateSelector()));

			// Next by configuring our routing rules
            var routes = new ControllerRouteCatalog(controllerFactory);
            routes.MapRoute("{controller}/{action}/{id}", new {controller = "Home", action = "Index", id = ""});

			// The NavigatorFactory is responsible for producing Navigators. This allows you to have multiple 
			// navigators with the same configuration (for example, tabbed browsing)
            var factory = new NavigatorFactory("tax", routes);
            var mainWindow = new MainWindow(factory);
            mainWindow.MainNavigator.Navigate<HomeController>(x => x.Index());
            mainWindow.Show();
        }
    }
}
