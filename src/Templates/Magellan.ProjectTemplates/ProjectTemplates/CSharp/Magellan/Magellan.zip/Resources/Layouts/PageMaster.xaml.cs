﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace $safeprojectname$.Resources.Layouts
{
    /// <summary>
    /// Interaction logic for PageMaster.xaml
    /// </summary>
    public partial class PageMaster : UserControl
    {
        public PageMaster()
        {
            InitializeComponent();
        }
    }
}
