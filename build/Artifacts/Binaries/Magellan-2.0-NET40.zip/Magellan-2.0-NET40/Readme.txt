Magellan is a lightweight framework that makes it easy to build WPF navigation applications. The design is 
drawn deeply from the ASP.NET MVC framework, and it should feel familiar to anyone who has worked with 
ASP.NET MVC. Magellan is open source and licensed under the BSD license.

 - [Magellan Homepage][1]
 - [Change Log][2]

Below is the latest automatic build. See the Archives directory for prior builds.

  [1]: http://www.paulstovell.com/magellan
  [2]: http://get.paulstovell.com/Magellan/Changelog.txt
